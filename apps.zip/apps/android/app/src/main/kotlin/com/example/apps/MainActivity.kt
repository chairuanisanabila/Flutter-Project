package com.example.apps

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
